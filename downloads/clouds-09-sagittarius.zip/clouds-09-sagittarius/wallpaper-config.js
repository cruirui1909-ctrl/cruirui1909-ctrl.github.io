window.CLOUD_WALLPAPER = {"scene": "sagittarius"};document.documentElement.classList.add("wallpaper-mode");
