# System Ruby + WEBrick. Loopback only; no downloads or installation.
require 'webrick'
root = File.expand_path(__dir__)
port = Integer(ARGV.fetch(0))
scene = ARGV.fetch(1)
server = WEBrick::HTTPServer.new(Port: port, BindAddress: '127.0.0.1', DocumentRoot: root,
  AccessLog: [], Logger: WEBrick::Log.new(File::NULL, WEBrick::Log::FATAL))
server.mount_proc('/clouds-health') do |_request, response|
  response['Content-Type'] = 'text/plain; charset=utf-8'
  response['Cache-Control'] = 'no-store'
  response.body = "clouds:#{scene}:#{root}"
end
trap('TERM') { server.shutdown }
trap('INT') { server.shutdown }
server.start
