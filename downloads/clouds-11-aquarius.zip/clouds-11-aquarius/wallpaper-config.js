window.CLOUD_WALLPAPER = {"scene": "aquarius"};document.documentElement.classList.add("wallpaper-mode");
