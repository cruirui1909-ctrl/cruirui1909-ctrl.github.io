#!/bin/zsh
set -eu
ROOT="$(cd -- "$(dirname -- "$0")" && pwd -P)"
cd "$ROOT"
source ./scene.env
if ! /usr/bin/open -gj -a Plash 2>/dev/null; then
  /usr/bin/open 'https://sindresorhus.com/plash'
  /usr/bin/osascript -e 'display alert "请先安装 Plash" message "安装完成后，再双击 Start-macOS.command。请选择官网中适合自己 macOS 版本的下载。"'
  exit 1
fi
HEALTH="http://127.0.0.1:${CLOUD_PORT}/clouds-health"
EXPECTED="clouds:${CLOUD_SCENE}:${ROOT}"
if [[ "$(/usr/bin/curl -fsS --max-time 1 "$HEALTH" 2>/dev/null || true)" != "$EXPECTED" ]]; then
  # Use the system Ruby when available; Python 3 is a fallback, not an installer.
  if [[ -x /usr/bin/ruby ]] && /usr/bin/ruby -rwebrick -e '' >/dev/null 2>&1; then
    nohup /usr/bin/ruby "$ROOT/serve-macos.rb" "$CLOUD_PORT" "$CLOUD_SCENE" > "$ROOT/.wallpaper-server.log" 2>&1 < /dev/null &
  elif command -v python3 >/dev/null && python3 --version >/dev/null 2>&1; then
    nohup python3 "$ROOT/serve-macos.py" "$CLOUD_PORT" "$CLOUD_SCENE" > "$ROOT/.wallpaper-server.log" 2>&1 < /dev/null &
  else
    /usr/bin/osascript -e 'display alert "需要一个本地网页运行环境" message "可安装 Python 3 后重试，或在 Plash 中手动添加本包的 index.html。壁纸文件已完整保存在本地。"'
    /usr/bin/open -R "$ROOT/index.html"
    exit 1
  fi
  SERVER_PID=$!
  print -r -- "$SERVER_PID" > "$ROOT/.wallpaper.pid"
  for attempt in {1..40}; do
    if [[ "$(/usr/bin/curl -fsS --max-time 1 "$HEALTH" 2>/dev/null || true)" == "$EXPECTED" ]]; then break; fi
    if ! kill -0 "$SERVER_PID" 2>/dev/null; then break; fi
    sleep 0.15
  done
fi
if [[ "$(/usr/bin/curl -fsS --max-time 1 "$HEALTH" 2>/dev/null || true)" != "$EXPECTED" ]]; then
  /usr/bin/osascript -e 'display alert "本地壁纸服务未能启动" message "端口可能被另一个同场景下载包占用。请先运行旧包的 Stop-macOS.command，再试一次。详情见本包 .wallpaper-server.log。"'
  exit 1
fi
/usr/bin/open -g "$CLOUD_PLASH_URL"
print '已将此场景发送到 Plash。鼠标与滚轮互动请在 Plash 菜单开启 Browsing Mode。'
print 'Plash 会将壁纸静音。关机后如需恢复，重新双击此启动文件。'
