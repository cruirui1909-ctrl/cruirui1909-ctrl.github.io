#!/bin/zsh
set -eu
ROOT="$(cd -- "$(dirname -- "$0")" && pwd -P)"
if [[ -f "$ROOT/.wallpaper.pid" ]]; then
  SERVER_PID="$(cat "$ROOT/.wallpaper.pid")"
  if [[ "$SERVER_PID" == <-> ]]; then
    RUNNING="$(ps -p "$SERVER_PID" -o command= 2>/dev/null || true)"
    if [[ "$RUNNING" == *"$ROOT/serve-macos.rb"* || "$RUNNING" == *"$ROOT/serve-macos.py"* ]]; then
      kill "$SERVER_PID" 2>/dev/null || true
    fi
  fi
fi
print '本场景的本地服务已停止。在 Plash 中选择其他壁纸即可。'
