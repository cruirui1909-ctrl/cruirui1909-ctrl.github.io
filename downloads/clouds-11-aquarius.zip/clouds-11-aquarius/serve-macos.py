"""Optional Python 3 fallback for the local Plash URL; stdlib only."""
import functools
import http.server
import sys
from pathlib import Path

root = str(Path(__file__).resolve().parent)
port, scene = int(sys.argv[1]), sys.argv[2]


class Handler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/clouds-health':
            body = f'clouds:{scene}:{root}'.encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(body)
        else:
            super().do_GET()

    def log_message(self, *_args):
        pass


http.server.ThreadingHTTPServer(('127.0.0.1', port), functools.partial(Handler, directory=root)).serve_forever()
