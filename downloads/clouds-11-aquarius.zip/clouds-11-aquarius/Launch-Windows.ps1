﻿param([switch]$Preview, [switch]$Check)
$ErrorActionPreference = 'Stop'
try {
    $project = Join-Path $PSScriptRoot 'project.json'
    if (!(Test-Path -LiteralPath $project)) { throw '请先完整解压下载包，再启动。' }
    $candidates = @()
    foreach ($name in @('wallpaper64','wallpaper32')) {
        $candidates += @(Get-Process -Name $name -ErrorAction SilentlyContinue | ForEach-Object { $_.Path })
    }
    $steamRoots = @("${env:ProgramFiles(x86)}\Steam", "$env:ProgramFiles\Steam")
    foreach ($key in @('HKCU:\Software\Valve\Steam','HKLM:\SOFTWARE\WOW6432Node\Valve\Steam')) {
        $entry = Get-ItemProperty -LiteralPath $key -ErrorAction SilentlyContinue
        if ($entry.SteamPath) { $steamRoots += $entry.SteamPath }
        if ($entry.InstallPath) { $steamRoots += $entry.InstallPath }
    }
    foreach ($root in @($steamRoots | Select-Object -Unique)) {
        $libraries = Join-Path $root 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $libraries) {
            $steamRoots += @([regex]::Matches([IO.File]::ReadAllText($libraries), '"path"\s+"([^"]+)"') | ForEach-Object { $_.Groups[1].Value.Replace('\\','\') })
        }
    }
    foreach ($root in @($steamRoots | Select-Object -Unique)) {
        $candidates += Join-Path $root 'steamapps\common\wallpaper_engine\wallpaper64.exe'
        $candidates += Join-Path $root 'steamapps\common\wallpaper_engine\wallpaper32.exe'
    }
    $engine = $candidates | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) } | Select-Object -First 1
    if (!$engine) {
        if ($Check) { throw '未检测到 Wallpaper Engine。' }
        Add-Type -AssemblyName System.Windows.Forms
        [void][Windows.Forms.MessageBox]::Show('需要先安装并运行 Wallpaper Engine（Steam 付费软件）。如已安装但未找到，请在下一步选择 wallpaper64.exe 或 wallpaper32.exe。','云彩没有尾巴')
        $picker = New-Object Windows.Forms.OpenFileDialog
        $picker.Filter = 'Wallpaper Engine|wallpaper64.exe;wallpaper32.exe'
        if ($picker.ShowDialog() -ne 'OK') { exit 1 }
        $engine = $picker.FileName
        if ([IO.Path]::GetFileName($engine) -notin @('wallpaper64.exe','wallpaper32.exe')) { throw '请选择 Wallpaper Engine 的启动程序。' }
    }
    if ($Check) {
        [pscustomobject]@{ engine=$engine; project=$project; scene=(Get-Content -LiteralPath (Join-Path $PSScriptRoot 'wallpaper.json') -Raw | ConvertFrom-Json).scene } | ConvertTo-Json -Compress
        exit 0
    }
    # Wallpaper Engine's CLI can lose non-ASCII paths. Keep its input path ASCII.
    if ($project -match '[^\x00-\x7F]') {
        $metadata = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'wallpaper.json') -Raw | ConvertFrom-Json
        if ($metadata.scene -notmatch '^(hall|aries|taurus|gemini|cancer|leo|virgo|libra|scorpio|sagittarius|capricorn|aquarius|pisces)$') { throw '壁纸场景标识无效。' }
        $cache = Join-Path ([Environment]::GetFolderPath('CommonDocuments')) ('CloudsWithoutTails\v26\' + $metadata.scene)
        if ($cache -match '[^\x00-\x7F]') { throw '请将下载包完整解压到一个只有英文字母和数字的目录，再启动。' }
        New-Item -ItemType Directory -Path $cache -Force | Out-Null
        foreach ($item in Get-ChildItem -LiteralPath $PSScriptRoot -Force) {
            Copy-Item -LiteralPath $item.FullName -Destination $cache -Recurse -Force
        }
        $project = Join-Path $cache 'project.json'
    }
    $engineArgs = '-control openWallpaper -file "' + $project + '"'
    if ($Preview) { $engineArgs += ' -playInWindow "CloudsWallpaperCheck" -width 1280 -height 720' }
    Start-Process -FilePath $engine -ArgumentList $engineArgs -WorkingDirectory ([IO.Path]::GetDirectoryName($engine))
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    if (!$Check) { Read-Host '按 Enter 关闭' | Out-Null }
    exit 1
}
