window.CLOUD_WALLPAPER = {"scene": "aries"};document.documentElement.classList.add("wallpaper-mode");
