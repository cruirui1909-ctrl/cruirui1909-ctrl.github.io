window.CLOUD_WALLPAPER = {"scene": "cancer"};document.documentElement.classList.add("wallpaper-mode");
