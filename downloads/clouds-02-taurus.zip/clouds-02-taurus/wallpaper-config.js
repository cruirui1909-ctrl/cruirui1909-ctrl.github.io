window.CLOUD_WALLPAPER = {"scene": "taurus"};document.documentElement.classList.add("wallpaper-mode");
