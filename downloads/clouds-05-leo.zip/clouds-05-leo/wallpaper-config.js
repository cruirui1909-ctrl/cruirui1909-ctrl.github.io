window.CLOUD_WALLPAPER = {"scene": "leo"};document.documentElement.classList.add("wallpaper-mode");
