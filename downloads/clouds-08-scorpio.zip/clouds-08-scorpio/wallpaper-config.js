window.CLOUD_WALLPAPER = {"scene": "scorpio"};document.documentElement.classList.add("wallpaper-mode");
