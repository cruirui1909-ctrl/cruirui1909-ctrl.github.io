window.CLOUD_WALLPAPER = {"scene": "libra"};document.documentElement.classList.add("wallpaper-mode");
