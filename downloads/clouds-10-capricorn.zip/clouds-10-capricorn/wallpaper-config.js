window.CLOUD_WALLPAPER = {"scene": "capricorn"};document.documentElement.classList.add("wallpaper-mode");
