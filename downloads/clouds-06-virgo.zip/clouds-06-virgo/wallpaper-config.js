window.CLOUD_WALLPAPER = {"scene": "virgo"};document.documentElement.classList.add("wallpaper-mode");
