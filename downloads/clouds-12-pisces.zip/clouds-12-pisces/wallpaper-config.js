window.CLOUD_WALLPAPER = {"scene": "pisces"};document.documentElement.classList.add("wallpaper-mode");
