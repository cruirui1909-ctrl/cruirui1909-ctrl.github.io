window.PIANO_TRACKS = Array(13).fill({"scene": "双鱼座 · 星河双湾", "composer": "萨蒂", "title": "第三号裸体舞曲", "en": "Gymnopédie No. 3", "file": "assets/music/12.mp3", "reason": "若即若离的和声与回旋感，陪伴星夜中的两道潮流。"});
