window.CLOUD_WALLPAPER = {"scene": "gemini"};document.documentElement.classList.add("wallpaper-mode");
