window.PIANO_TRACKS = Array(13).fill({"scene": "双子座 · 双丘云间", "composer": "德彪西", "title": "第一号阿拉伯风格曲", "en": "Arabesque No. 1, L. 66", "file": "assets/music/03.mp3", "reason": "交错的分解和弦，如两团云交换方向。"});
